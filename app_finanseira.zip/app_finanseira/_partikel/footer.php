<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?= date('Y') ?> - Developed By
                <b><a href="#" target="_blank">Finanseira</a></b>
            </span>
        </div>
    </div>
</footer>